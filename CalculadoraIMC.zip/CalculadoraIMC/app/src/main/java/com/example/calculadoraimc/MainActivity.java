package com.example.calculadoraimc;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText edAltura;
    private EditText edPeso;
    private Button btHomem;
    private Button btMulher;
    private TextView txResultado;
    private TextView txHistorico; // Adicionando TextView para o histórico

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        edAltura = findViewById(R.id.edAltura);
        edPeso = findViewById(R.id.edPeso);
        btHomem = findViewById(R.id.btHomem);
        btMulher = findViewById(R.id.btMulher);
        txResultado = findViewById(R.id.txResultado);
        txHistorico = findViewById(R.id.txHistorico); // Inicializando o histórico

        btHomem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double imc = calcularIMC();
                calcularIMCHomem(imc);
            }
        });

        btMulher.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double imc = calcularIMC();
                calcularIMCMulher(imc);
            }
        });
    }

    private double calcularIMC() {
        String strPeso = edPeso.getText().toString();
        double peso = Double.parseDouble(strPeso);

        String strAltura = edAltura.getText().toString();
        double altura = Double.parseDouble(strAltura);

        return peso / (altura * altura);
    }

    private void calcularIMCHomem(double imc) {
        String msg = "";
        if (imc < 20.7) {
            msg = "Abaixo do peso";
        } else if (imc >= 20.7 && imc < 26.4) {
            msg = "Peso normal";
        } else {
            msg = "Acima do peso";
        }

        String resultado = String.format("%.4f", imc); // Limitar a 4 casas decimais
        txResultado.setText("O IMC é: " + resultado + " - " + msg);
        atualizarHistorico("Homem: " + resultado + " - " + msg);
    }

    private void calcularIMCMulher(double imc) {
        String msg = "";
        if (imc < 19.1) {
            msg = "Abaixo do peso";
        } else if (imc >= 19.1 && imc < 25.8) {
            msg = "Peso normal";
        } else {
            msg = "Acima do peso";
        }

        String resultado = String.format("%.4f", imc); // Limitar a 4 casas decimais
        txResultado.setText("O IMC é: " + resultado + " - " + msg);
        atualizarHistorico("Mulher: " + resultado + " - " + msg);
    }

    private void atualizarHistorico(String resultado) {
        String historicoAtual = txHistorico.getText().toString();
        txHistorico.setText(historicoAtual + "\n" + resultado); // Adiciona o novo resultado ao histórico
    }
}